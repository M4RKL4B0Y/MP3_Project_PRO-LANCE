
# Pro-Lance CRM

## Description

## Features

## Prerequisites 

Refer to the following GitHub issue for more information on setting the base URL using axios.create,:

## BaseURL Configuration

To set up the base URL for API requests, refer to the following issue on GitHub: 
[How to Get the BaseURL from axios.create({baseURL})? #2985](https://github.com/axios/axios/issues/2985) by KaizenTamashi.
